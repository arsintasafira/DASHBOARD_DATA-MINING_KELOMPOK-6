"""Bangun dashboard bencana BNPB. Pengolahan data memakai DuckDB (SQL).
Siapkan folder `data/` di samping file ini, isi: semua file .xlsx BNPB (boleh di subfolder),
kabupaten_kota_indonesia.csv, indonesia-38-prov-kabupaten-kota.geojson, indonesia-38-provinces.geojson,
dan file template.html. Jalankan: python build_dashboard.py
Pasang dulu: pip install duckdb pandas openpyxl"""
import glob, json, re
from pathlib import Path
import duckdb, pandas as pd

DATA = Path(__file__).parent.parent / 'dataset data mining'
OUT = Path(__file__).parent / 'dashboard_bencana_bnpb.html'
DB = Path(__file__).parent / 'bencana.duckdb'
K=40; X0=94; Y0=6.5
def pr(lon,lat): return (round((lon-X0)*K),round((Y0-lat)*K))
def rdp(pts,eps):
    if len(pts)<5: return pts
    keep=[False]*len(pts); keep[0]=keep[-1]=True; st=[(0,len(pts)-1)]
    while st:
        a,b=st.pop(); (x1,y1),(x2,y2)=pts[a],pts[b]; dx,dy=x2-x1,y2-y1; L=dx*dx+dy*dy; mx=-1; mi=-1
        for i in range(a+1,b):
            x,y=pts[i]
            if L==0: d=(x-x1)**2+(y-y1)**2
            else:
                t=max(0,min(1,((x-x1)*dx+(y-y1)*dy)/L)); d=(x-x1-t*dx)**2+(y-y1-t*dy)**2
            if d>mx: mx=d; mi=i
        if mx>eps*eps: keep[mi]=True; st+=[(a,mi),(mi,b)]
    return [p for p,k in zip(pts,keep) if k]
def area(r): return abs(sum(r[i][0]*r[i-1][1]-r[i-1][0]*r[i][1] for i in range(len(r))))/2
def path(geom,eps):
    polys=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
    out=[];best=None
    for poly in polys:
        for ring in poly:
            p=[pr(*c[:2]) for c in ring]; q=[p[0]]
            for z in p[1:]:
                if z!=q[-1]: q.append(z)
            q=rdp(q,eps)
            if len(q)<4: continue
            a=area(q)
            if best is None or a>best[0]: best=(a,q)
            if a>=1.5: out.append(q)
    if not out and best: out=[best[1]]
    return ''.join('M'+'L'.join(f'{x} {y}' for x,y in r)+'Z' for r in out)

# ---------- 1. Muat data mentah ke DuckDB ----------
frames = [pd.read_excel(f, header=1) for f in sorted(glob.glob(str(DATA / '**' / '*.xlsx'), recursive=True))]
raw = pd.concat(frames, ignore_index=True)
raw = raw[pd.to_numeric(raw['No.'], errors='coerce').notna()]
num = lambda c: pd.to_numeric(raw[c], errors='coerce').fillna(0).astype(int)
df = pd.DataFrame({
    'jenis': raw['Kejadian'].astype(str).str.strip(),
    'tgl': pd.to_datetime(raw['Tanggal Kejadian'], errors='coerce'),
    'kode_kab': pd.to_numeric(raw['ID Kabupaten'], errors='coerce').astype('Int64'),
    'meninggal': num('Meninggal'), 'hilang': num('Hilang'), 'terluka': num('Terluka'),
    'rumah_rusak': num('Rumah Rusak'), 'rumah_terendam': num('Rumah Terendam'), 'fasum_rusak': num('Fasum Rusak'),
})
con = duckdb.connect(str(DB))
con.register('df_mentah', df)
con.execute('CREATE OR REPLACE TABLE kejadian_mentah AS SELECT * FROM df_mentah')
csv_path = (DATA / 'kabupaten_kota_indonesia.csv').as_posix()
con.execute(f"""CREATE OR REPLACE TABLE wilayah AS
  SELECT CAST(REPLACE("Kode Kemendagri", '.', '') AS INTEGER) AS kode,
         CAST("Kode Provinsi" AS INTEGER) AS kode_prov, "Provinsi" AS provinsi,
         "Nama Kabupaten/Kota" AS nama,
         COALESCE(TRY_CAST("Penduduk" AS DOUBLE), 0) AS penduduk,
         COALESCE(TRY_CAST("Luas (km²)" AS DOUBLE), 0) AS luas
  FROM read_csv('{csv_path}', header = true, all_varchar = true)""")

# ---------- 2. Bersihkan & gabungkan dengan SQL ----------
con.execute("""CREATE OR REPLACE TABLE kejadian AS
  SELECT jenis, tgl, kode_kab,
         (year(tgl) - 2025) * 12 + month(tgl) - 1 AS bulan_idx,
         meninggal, hilang, terluka, rumah_rusak, rumah_terendam, fasum_rusak
  FROM kejadian_mentah
  WHERE kode_kab IS NOT NULL AND tgl IS NOT NULL""")
con.execute("""CREATE OR REPLACE TABLE rekap_jenis AS
  SELECT jenis, COUNT(*) AS kejadian, SUM(meninggal) AS meninggal, SUM(hilang) AS hilang, SUM(terluka) AS terluka,
         SUM(rumah_rusak) AS rumah_rusak, SUM(rumah_terendam) AS rumah_terendam, SUM(fasum_rusak) AS fasum_rusak
  FROM kejadian GROUP BY jenis ORDER BY kejadian DESC""")
con.execute("""CREATE OR REPLACE TABLE rekap_provinsi AS
  SELECT w.provinsi, COUNT(*) AS kejadian, SUM(k.meninggal) AS meninggal, SUM(k.hilang) AS hilang, SUM(k.terluka) AS terluka,
         SUM(k.rumah_rusak) AS rumah_rusak, SUM(k.rumah_terendam) AS rumah_terendam, SUM(k.fasum_rusak) AS fasum_rusak
  FROM kejadian k JOIN wilayah w ON k.kode_kab = w.kode GROUP BY w.provinsi ORDER BY kejadian DESC""")
con.execute("""CREATE OR REPLACE TABLE rekap_bulan AS
  SELECT bulan_idx, jenis, COUNT(*) AS kejadian FROM kejadian GROUP BY bulan_idx, jenis ORDER BY bulan_idx, jenis""")

n_all = con.execute('SELECT COUNT(*) FROM kejadian_mentah').fetchone()[0]
n_ok = con.execute('SELECT COUNT(*) FROM kejadian').fetchone()[0]
n_noreg = con.execute('SELECT COUNT(*) FROM kejadian k LEFT JOIN wilayah w ON k.kode_kab = w.kode WHERE w.kode IS NULL').fetchone()[0]
print(f'baris mentah: {n_all} | lolos pembersihan: {n_ok} | kode kab tidak ada di CSV: {n_noreg}')
print(con.execute('SELECT * FROM rekap_jenis').df().to_string(index=False))

# ---------- 3. Ambil hasil SQL untuk dashboard ----------
types = [r[0] for r in con.execute('SELECT jenis FROM kejadian GROUP BY jenis ORDER BY COUNT(*) DESC, jenis').fetchall()]
rows = con.execute("""SELECT bulan_idx, jenis, kode_kab, meninggal, hilang, terluka, rumah_rusak, rumah_terendam, fasum_rusak
                      FROM kejadian ORDER BY tgl, kode_kab""").fetchall()
ev = [[int(r[0]), types.index(r[1]), int(r[2])] + [int(x) for x in r[3:]] for r in rows]
months = [f'{2025 + i // 12}-{i % 12 + 1:02d}' for i in range(13)]
reg, prov, pp = {}, {}, {}
for kode, kp, pv, nama, pop, luas in con.execute('SELECT kode, kode_prov, provinsi, nama, penduduk, luas FROM wilayah').fetchall():
    reg[kode] = [nama.replace('Kabupaten ', 'Kab. '), kp, int(pop), luas]
    prov[kp] = pv
    pp[kp] = pp.get(kp, 0) + int(pop)
con.close()

# ---------- 4. Peta (GeoJSON) ----------
norm=lambda x:re.sub(r'[^a-z0-9]','',x.lower())
csvk={(norm(prov[v[1]]),norm(v[0].replace('Kab. ',''))):c for c,v in reg.items()}
provcode={norm(n):c for c,n in prov.items()}
g2=json.load(open(DATA/'indonesia-38-prov-kabupaten-kota.geojson',encoding='utf-8'));g1=json.load(open(DATA/'indonesia-38-provinces.geojson',encoding='utf-8'))
kab={};nomatch=[]
for f in g2['features']:
    p=f['properties']; k=csvk.get((norm(p['PROVINSI']),norm(re.sub('^Kabupaten ','',p['KAB_KOTA']))))
    if k is None: k=int(p['KODE_KK'].replace('.','')); nomatch.append((p['KODE_KK'],p['KAB_KOTA'],p['PROVINSI']))
    kab[k]=path(f['geometry'],0.6)
    if k not in reg: reg[k]=[p['KAB_KOTA'],k//100,0,0]
provp={}
for f in g1['features']:
    p=f['properties']; k=provcode.get(norm(p['PROVINSI']),int(p['KODE_PROV'])); provp[k]=path(f['geometry'],1.0); prov[k]=p['PROVINSI']
print('poligon kab tanpa padanan nama di CSV:',len(nomatch),nomatch[:10])
used=set(r[2] for r in ev)
miss=sorted(used-set(kab)); 
print('kejadian dipakai:',len(ev))
print('kode kab di data tapi tidak ada di peta:',len(miss),miss[:15],'=>',sum(1 for r in ev if r[2] in miss),'kejadian')
print('kode kab di data tapi tidak ada di CSV:',sorted(used-set(reg))[:15])
print('poligon kab:',len(kab),'prov:',len(provp))
D=dict(types=types,months=months,reg={str(k):v for k,v in reg.items()},prov={str(k):v for k,v in prov.items()},provPop={str(k):v for k,v in pp.items()},
       ev=ev,kab={str(k):v for k,v in kab.items()},provPath={str(k):v for k,v in provp.items()},vb=f'-10 -10 {round((141.2-X0)*K)+20} {round((Y0+11.2)*K)+20}')
js=json.dumps(D,ensure_ascii=False,separators=(',',':'))
html=open(Path(__file__).parent/'template.html',encoding='utf-8').read().replace('/*DATA*/null',js)
OUT.write_text(html,encoding='utf-8')
print('ukuran HTML:',round(len(html)/1024),'KB')
